package modell;

public class RendszamExeption extends IllegalArgumentException {

    public RendszamExeption(String s) {
        super(s);
    }
}
