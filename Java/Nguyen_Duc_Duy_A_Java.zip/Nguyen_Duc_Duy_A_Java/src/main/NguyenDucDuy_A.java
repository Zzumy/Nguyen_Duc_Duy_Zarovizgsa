package main;

import nezet.GuiForm;
import nezet.Konzol;

public class NguyenDucDuy_A {

    public static void main(String[] args) {
        new Konzol().feladatok();
        new GuiForm().setVisible(true);

    }

}
